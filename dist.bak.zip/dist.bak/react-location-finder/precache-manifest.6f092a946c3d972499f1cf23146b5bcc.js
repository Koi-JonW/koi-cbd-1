self.__precacheManifest = (self.__precacheManifest || []).concat([
  {
    "revision": "48148470872834d21018de7a155c6a5f",
    "url": "/index.html"
  },
  {
    "revision": "5592cb3b2d4c25ddc24f",
    "url": "/static/css/main.f6a8accc.chunk.css"
  },
  {
    "revision": "a86e6ed70cbefaf2b869",
    "url": "/static/js/2.c783649b.chunk.js"
  },
  {
    "revision": "5592cb3b2d4c25ddc24f",
    "url": "/static/js/main.6b7e6470.chunk.js"
  },
  {
    "revision": "8c274747b4045e5ca996",
    "url": "/static/js/runtime-main.922656fd.js"
  }
]);